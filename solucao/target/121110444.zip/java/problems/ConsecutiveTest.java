//package problems;
//
//import static org.junit.Assert.*;
//
//import java.util.Set;
//
//
//import org.junit.Test;
//
//
//
//public class ConsecutiveTest {
//	
//	BSTInteger bst = new BSTInteger();
//	ConsecutiveParentChildBSTImpl consecutive = new ConsecutiveParentChildBSTImpl();
//		
//	@Test
//	public void test01() {
//		Integer[] array = new Integer[] {2, 1, 5, 6, 19, 29, 30, 31};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test02() {
//		Integer[] array = new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test03() {
//		Integer[] array = new Integer[] {10, 9, 8, 7, 6, 5, 4, 3, 2,1};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test04() {
//		Integer[] array = new Integer[] {};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test05() {
//		Integer[] array = new Integer[] {10, 9};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test06() {
//		Integer[] array = new Integer[] {10};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//	
//	@Test
//	public void test07() {
//		Integer[] array = new Integer[] {0, -1};
//		for (Integer integer : array) {
//			this.bst.insert(integer);
//		}
//		
//		Set<Pair> out = consecutive.findConsecutivesTest(bst);
//		
//		System.out.println("------------------------");
//	
//	}
//
//}
